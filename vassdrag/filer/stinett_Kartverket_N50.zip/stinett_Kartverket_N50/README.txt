Dette datasettet er hentet fra Kartverkets N50 datasett.

https://kartkatalog.geonorge.no/metadata/n50-kartdata/ea192681-d039-42ec-b1bc-f3ce04c189ac


