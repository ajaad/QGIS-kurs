Beskrivelse av filene
=====================

Shapefil med hjelpefiler kan lastes inn i QGIS.

.qml- og .sld-filene er stylingfiler.

.qml-filene kan fungere som hjelpefiler til shapeformatet

=====================

# [GPS Exchange Format](https://en.wikipedia.org/wiki/GPS_Exchange_Format)
 .gpx-filen kan lasted inn i OsmAnd
og håndholdte Garminenheter via BaseMap eller Mapsource.


# [Keyhole Markup Language](https://en.wikipedia.org/wiki/Keyhole_Markup_Language)
.kml-filen kan lastes inn i både Google Earth og OruxMaps

OruxMaps er ikke open-soruce, men det er gratis.
.kml-formatet støtter fargelegging.
Egenskapene blir også med.

I OruxMaps er det også mulig å bruke "Exclution zone"-funksjonen.
Da vil mobilen / pad'en gi en signallyd når du er inne i hogstområdet.

=====================
