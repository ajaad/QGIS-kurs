## GPS Logger

Disse sporene er fanget med en Garmin eTrex Legend HCx
Denne enheten kan bli innstilt til å skrve koordinater direkte til en minnebrikke.
Koordinatene kan hentets ut ved å putte minnebrikken inn i PC'n og kopiere GPX-filene.

Denne gps-enheten logger koordinatene i lengdegrader og breddegrader med seks desimalers oppløsning.
For disse filene har jeg valgt å bruke en temorær oppløsning på ett sekund.

Filnavnet angir dato slik: %Y%m%d.gpx
Filen 20200722.gpx ble altså generert den 22.juli 2020.




